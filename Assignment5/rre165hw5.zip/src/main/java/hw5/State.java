package hw5;

public interface State {
	public void firstFloorPressed();
	public void secondFloorPressed();
	public void thirdFloorPressed();
}
